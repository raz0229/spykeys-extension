<html>
    <head>
    </head>
    <body>
        <h2>SpyKeys</h2>
        <div><b>Version:</b> 1.0</div>
        <div><b>Author:</b> <em>@raz0229</em></div>
        <div><b>Updated:</b> 2021.12.26</div>
        <div><b>Description:</b> Real-time alphanumeric and symbol keys logger.
        Users have complete access to their data. Synced with remote database so your data can be accessed anywhere.</div>
        <div><b>View Logs:</b> https://spykeys.vercel.app</div>
        <div><b>Bundled Software / Libraries:</b></div>
        <div>
            <ul>
                <li>jQuery 1.9.1: http://jquery.com/</li>
                <li>MaterializeCSS 2.3.1: https://materializecss.com/getting-started.html</li>
                <li>Font Awesome 3.0.2: http://fortawesome.github.io/Font-Awesome/</li>
            </ul>
        </div>
        <div>Your support by sharing, would be appreicated!</div>
    </body>
</html>