
// Check the cookie on page load
window.onload = exists();
